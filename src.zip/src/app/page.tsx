import Posts from '@/components/PostContainer';

export default function PostsPage() {
  return (
    <div className='flex flex-col px-5 sm:px-20'>
      <Posts />
    </div>
  );
}
